package ativi_exceptions;

public class Program {
    public static void main(String[] args) {
        Estudante estudante = new Estudante(12345);
        Orientador orientador1 = new Orientador("João");
        Orientador orientador2 = new Orientador("Maria");
        Orientador orientador3 = new Orientador("lucas");

        try {
            orientador1.orientarAluno(estudante);
            orientador2.orientarAluno(estudante);
            orientador3.orientarAluno(estudante);
        } catch (LimiteAlunosException | LimiteOrientadoresException e) {
            System.out.println(e.getMessage());
        }
    }
}
