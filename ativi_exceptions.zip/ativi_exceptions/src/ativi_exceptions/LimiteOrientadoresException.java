package ativi_exceptions;

public class LimiteOrientadoresException extends Exception {
    public LimiteOrientadoresException(String message) {
        super(message);
    }
}
