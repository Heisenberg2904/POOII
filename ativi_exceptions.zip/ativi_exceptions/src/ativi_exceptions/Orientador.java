package ativi_exceptions;


import java.util.ArrayList;
import java.util.List;


public class Orientador {
    private String nome;
    private List<Estudante> alunosOrientados;

    public Orientador(String nome) {
        this.nome = nome;
        this.alunosOrientados = new ArrayList<>();
    }

    public String getNome() {
        return nome;
    }

    public void orientarAluno(Estudante estudante) throws LimiteAlunosException, LimiteOrientadoresException {
        if (alunosOrientados.size() >= 3) {
            throw new LimiteAlunosException("Limite de alunos orientados atingido para o orientador " + nome);
        }
        estudante.adicionarOrientador(this);
        alunosOrientados.add(estudante);
    }
}
