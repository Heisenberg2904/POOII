package ativi_exceptions;

import java.util.ArrayList;
import java.util.List;

public class Estudante {
    private int matricula;
    private List<Orientador> orientadores;

    public Estudante(int matricula) {
        this.matricula = matricula;
        this.orientadores = new ArrayList<>();
    }

    public int getMatricula() {
        return matricula;
    }

    public void adicionarOrientador(Orientador orientador) throws LimiteAlunosException {
        if (orientadores.size() >= 2) {
            throw new LimiteAlunosException("Limite de orientadores atingido para o estudante de matrícula " + matricula);
        }
        orientadores.add(orientador);
    }
}

