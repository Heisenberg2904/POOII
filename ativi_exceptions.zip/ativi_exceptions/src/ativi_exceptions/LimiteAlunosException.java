package ativi_exceptions;

public class LimiteAlunosException extends Exception {
    public LimiteAlunosException(String message) {
        super(message);
    }
}
