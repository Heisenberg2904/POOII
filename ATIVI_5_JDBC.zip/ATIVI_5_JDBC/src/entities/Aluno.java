package entities;


import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import jdbc.AlunoJDBC;

public class Aluno {

	private int id;
	private String nome;
	private String sexo;
	private LocalDate dt_nasc;
	
	
	
	
	public Aluno() {
		
	}
	public Aluno(int id, String nome, String sexo, LocalDate dt_nasc2) {
		super();this.id = id;
		this.nome = nome;
		this.sexo = sexo;
		this.dt_nasc = dt_nasc2;
	}
	
	public void listar() throws IOException, SQLException {
		List<Aluno> alunos = new ArrayList<>();
		AlunoJDBC ACAO = new AlunoJDBC();
		alunos= ACAO.listarALU();
		if(alunos.isEmpty()) {
		System.out.println("A lista esta vazia");
		}else {
			for(int i = 0;i<alunos.size();i++) {
				Aluno aluno=alunos.get(i);
				System.out.println("\nid:"+aluno.id+"\nNome:"+aluno.nome+"\nSexo:"+aluno.sexo+"\nData de Nacimento:"+aluno.dt_nasc);
				System.out.println("----------------------------------------------\n");
			}
		}
			
		}
		
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSexo() {
		return sexo;
	}
	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
	public LocalDate getDt_nasc() {
		return dt_nasc;
	}
	public void setDt_nasc(LocalDate localDate) {
		this.dt_nasc = localDate;
	}
	
	
}
