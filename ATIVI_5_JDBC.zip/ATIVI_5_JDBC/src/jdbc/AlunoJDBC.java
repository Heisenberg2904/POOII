package jdbc;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import entities.Aluno;

public class AlunoJDBC {

	Connection con;
	String sql;
	PreparedStatement pst;
	
	public void salvar(Aluno a) throws SQLException {
		
		try {
			con = db.getConexao();
			sql = "INSERT INTO aluno (nome, sexo, dt_nasc) VALUES (?,?, ?)";
			pst = con.prepareStatement(sql);
			pst.setString(1, a.getNome());
			pst.setString(2, a.getSexo());
			Date dataSql = Date.valueOf( a.getDt_nasc() );
			pst.setDate(3, dataSql);
			pst.executeUpdate();
			System.out.println("\nCadastro do aluno realizado com sucesso!");
			
		} catch (Exception e) {
			System.out.println(e);
		}
		finally {
			pst.close();
			db.closeConexao();
		}
	}
	
	public List<Aluno> listarALU() throws IOException, SQLException{
		
		try {
		
		con = db.getConexao();
		sql = "SELECT * FROM ALUNO";
		pst = con.prepareStatement(sql);
		ResultSet resultSet=pst.executeQuery();
		List<Aluno> result = new ArrayList<>();
		while(resultSet.next()) {
			int id=resultSet.getInt(1);
			//Date dt_nasc= resultSet.getDate(1);
			Date dateFromDB=resultSet.getDate(2);
			LocalDate dt_nasc = dateFromDB.toLocalDate();
			String nome=resultSet.getString(3);
			String sexo=resultSet.getString(4);
			Aluno aluno=new Aluno(id,nome,sexo,dt_nasc);
			result.add(aluno);
			
		}
		return result;
		
			
	}catch (SQLException e) {
        System.out.println(e);
	}
		finally {
		pst.close();
		db.closeConexao();
	}
		return null;
	}
	
	public void apagar(int id) throws IOException, SQLException {
		try {
		con = db.getConexao();
		sql = "Delete from aluno where idaluno=?";
		pst = con.prepareStatement(sql);
		pst.setInt(1,id );
		pst.executeUpdate();
		System.out.println("Sucesso");
		}catch (Exception e) {
			System.out.println(e);
		}
		finally {
			pst.close();
			db.closeConexao();
		}
	}
	
	public void alterar(Aluno a,int Nome)throws IOException, SQLException  {
		try {
			con = db.getConexao();
			sql = "Update aluno Set nome=?,sexo=?,dt_nasc=? WHERE idaluno=?";
			pst = con.prepareStatement(sql);
			pst.setString(1, a.getNome());
			Date dataSql = Date.valueOf( a.getDt_nasc() );
			pst.setDate(3, dataSql);
			pst.setString(2, a.getSexo()); 
			pst.setInt(4, Nome);
			pst.executeUpdate();
			System.out.println("Atualizado com Sucesso");
			}catch (Exception e) {
				System.out.println(e);
			}
			finally {
				pst.close();
				db.closeConexao();
			}
		}
		
	}

