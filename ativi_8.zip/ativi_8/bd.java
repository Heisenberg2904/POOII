https://start.spring.io/

CREATE TABLE curso (
    idcurso SERIAL,
    nomeCurso varchar(40),
    PRIMARY KEY (idcurso)
);

INSERT INTO curso (nomeCurso) VALUES ('Sistema de Informação');
INSERT INTO curso (nomeCurso) VALUES ('Engenharia Civil');

CREATE TABLE aluno (
    id SERIAL,
    nome varchar(40),
    sexo varchar(10),
    dt_nasc date,
    nota numeric,
    PRIMARY KEY (id)
);

INSERT INTO aluno (nome, sexo, dt_nasc, nota) VALUES ('Dory', 'Masculino', '1976-03-31', 10);
INSERT INTO aluno (nome, sexo, dt_nasc, nota) VALUES ('Caroline', 'Feminino', '2000-12-24', 7);
INSERT INTO aluno (nome, sexo, dt_nasc, nota) VALUES ('Isabelle', 'Feminino', '2010-01-01', 8.5);
INSERT INTO aluno (nome, sexo, dt_nasc, nota) VALUES ('Ana Laura', 'Feminino', '2005-05-05', 7.3);
INSERT INTO aluno (nome, sexo, dt_nasc, nota) VALUES ('João', 'Masculino', '2000-01-01', 9.5);


CREATE TABLE disciplina
(
    id SERIAL,
    nome varchar(60) NOT NULL,
    cargah integer NOT NULL,
    PRIMARY KEY (id)
);

INSERT INTO disciplina (nome, cargaha) VALUES ('BD2', 54);
INSERT INTO disciplina (nome, cargah) VALUES ('POO II', 72);