package clas;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import clas.Automovel;
import clas.Marca;
import clas.Modelo;
		

public class Program {
    public static void main(String[] args) {
        // Criar o EntityManagerFactory
        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("ativi_7");

        // Criar o EntityManager
        EntityManager entityManager = entityManagerFactory.createEntityManager();

        // Iniciar uma transação
        entityManager.getTransaction().begin();

        // Criar as instâncias de Marca, Modelo e Automovel
        Marca marca = new Marca("volvo");
        Modelo modelo = new Modelo("xc40", 150, marca);
        Automovel automovel = new Automovel(2021, 2022, "Sem observações", 50000, 10000, modelo);

        // Persistir as entidades no banco de dados
        entityManager.persist(marca);
        entityManager.persist(modelo);
        entityManager.persist(automovel);

        // Commit na transação
        entityManager.getTransaction().commit();

        // Fechar o EntityManager e o EntityManagerFactory
        entityManager.close();
        entityManagerFactory.close();
    }
}
