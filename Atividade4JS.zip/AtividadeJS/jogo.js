window.onload = function() {
  var tentativas = 0;
  var resultadoBrasil = Math.floor(Math.random() * 6); // Gols aleatórios para o Brasil (0 a 5)
  var resultadoAlemanha = Math.floor(Math.random() * 6); // Gols aleatórios para a Alemanha (0 a 5)

  var btnPalpite = document.getElementById("btnPalpite");
  var btnReiniciar = document.getElementById("btnReiniciar");
  var inputBrasil = document.getElementById("inputBrasil");
  var inputAlemanha = document.getElementById("inputAlemanha");
  var resultado = document.getElementById("resultado");
  var dicas = document.getElementById("dicas");
  var listaPalpites = document.getElementById("listaPalpites");

  btnPalpite.addEventListener("click", function() {
    var palpiteBrasil = parseInt(inputBrasil.value);
    var palpiteAlemanha = parseInt(inputAlemanha.value);

    if (tentativas < 10) {
      tentativas++;
      if (palpiteBrasil === resultadoBrasil && palpiteAlemanha === resultadoAlemanha) {
        resultado.innerHTML = "Parabéns! Você acertou o placar!";
        btnPalpite.disabled = true;
      } else {
        if (palpiteBrasil > resultadoBrasil) {
          dicas.innerHTML = "Seu palpite para o Brasil foi alto.";
        } else {
          dicas.innerHTML = "Seu palpite para o Brasil foi baixo.";
        }

        if (palpiteAlemanha > resultadoAlemanha) {
          dicas.innerHTML += " Seu palpite para a Alemanha foi alto.";
        } else {
          dicas.innerHTML += " Seu palpite para a Alemanha foi baixo.";
        }
      }

      var palpite = document.createElement("li");
      palpite.textContent = "Brasil " + palpiteBrasil + " x " + palpiteAlemanha + " Alemanha";
      listaPalpites.appendChild(palpite);
    } else {
      resultado.innerHTML = "Fim de jogo. Suas tentativas acabaram.";
      btnPalpite.disabled = true;
    }
  });

  btnReiniciar.addEventListener("click", function() {
    resultadoBrasil = Math.floor(Math.random() * 6);
    resultadoAlemanha = Math.floor(Math.random() * 6);
    tentativas = 0;
    resultado.innerHTML = "";
    dicas.innerHTML = "";
    listaPalpites.innerHTML = "";
    btnPalpite.disabled = false;
  });
};
